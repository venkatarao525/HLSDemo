//
//  ReverseProxyResourceLoader.swift
//  HLSDemo
//
//  Created by Gajje.Venkatarao on 12/12/24.
//

import Foundation
import AVKit
import AVFoundation


class ReverseProxyResourceLoader: NSObject, AVAssetResourceLoaderDelegate {
    
    var cookie = ""
    
    func resourceLoader(_ resourceLoader: AVAssetResourceLoader, shouldWaitForLoadingOfRequestedResource loadingRequest: AVAssetResourceLoadingRequest) -> Bool {
        
        resourceLoader.preloadsEligibleContentKeys = true
        guard let interceptedURL = loadingRequest.request.url else {
            loadingRequest.finishLoading(with: NSError(domain: "ReverseProxy", code: -1, userInfo: [NSLocalizedDescriptionKey: "Invalid URL"]))
            return false
        }
        
        if interceptedURL.scheme == "skd" {
            
            print("Token updated Cookie:", interceptedURL )
            return false
        }
        
        var components = URLComponents(url: interceptedURL, resolvingAgainstBaseURL: false)
        components?.scheme = "https" // Replace with the original scheme
        guard let originalURL = components?.url else {
            loadingRequest.finishLoading(with: NSError(domain: "ReverseProxy", code: -1, userInfo: [NSLocalizedDescriptionKey: "Failed to map URL"]))
            loadingRequest.finishLoading()
            return false
        }
        
        var request = URLRequest(url: originalURL)
        
        request.httpMethod = "GET"
        

        if let storeCoockie = HTTPCookie(properties: [
            .name: "dazn-token",
            .value: cookie,
            .domain: originalURL.host ?? "",
            .path: "/",
            .discard: true
        ]){
            
            HTTPCookieStorage.shared.setCookie(storeCoockie)
        }
        
        let headers = loadingRequest.request.allHTTPHeaderFields ?? [:]
        for (key, value) in headers {
            request.addValue(value, forHTTPHeaderField: key)
            
        }
        request.addValue(cookie, forHTTPHeaderField: "Cookie")
        URLSession.shared.configuration.httpShouldSetCookies = true
        request.httpShouldHandleCookies = true
        
        
        let task = (URLSession.shared.dataTask(with: originalURL) { data, response, error in
            if let error = error {
                print("Error Received:", error)
                loadingRequest.finishLoading(with: error)
                
                return
            }
            print(originalURL)
            guard let data = data , let url = response?.url else {
                loadingRequest.finishLoading(with: NSError(domain: "ReverseProxy", code: -1, userInfo: [NSLocalizedDescriptionKey: "No data received"]))
                return
            }
            
            loadingRequest.dataRequest?.respond(with: data)
            
            loadingRequest.finishLoading()
        } as URLSessionDataTask)
        
        task.resume()
        
        
        return true
    }
}

