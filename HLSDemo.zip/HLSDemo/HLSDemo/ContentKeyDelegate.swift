//
//  ContentKeyDelegate.swift
//  HLSDemo
//
//  Created by Gajje.Venkatarao on 12/12/24.
//

import Foundation
import AVKit
import AVFoundation


public class ContentKeyDelegate: NSObject, AVContentKeySessionDelegate {
    
    // Called when the session receives a key request
    public func contentKeySession(_ session: AVContentKeySession, didProvide keyRequest: AVContentKeyRequest) {
          

           // Send the request data to the license server
           fetchContentKey(for: Data()) { [weak keyRequest] licenseData in
               guard let keyRequest = keyRequest else { return }

               if let licenseData = licenseData {
                   // Provide the license to the key request
                  // keyRequest.processContentKeyResponse(licenseData)
               } else {
                   // Handle failure
                 //  keyRequest.processContentKeyRequest(withResponse: nil)
                   print("Failed to process content key request")
               }
           }
       }

       // Called when a key request has been invalidated
    public func contentKeySession(_ session: AVContentKeySession, didProvideRenewingContentKeyRequest keyRequest: AVContentKeyRequest) {
           print("Received renewing content key request")
           contentKeySession(session, didProvide: keyRequest)
       }

       // Called when a persistent content key is not allowed
    public func contentKeySession(_ session: AVContentKeySession, contentKeyRequest keyRequest: AVContentKeyRequest, didFailWithError error: Error) {
           print("Content key request failed with error: \(error.localizedDescription)")
       }

       // Handle expired sessions
    public func contentKeySessionDidGenerateExpiredSessionReport(_ session: AVContentKeySession) {
           print("Content key session expired")
       }
    
    func contentKeySession(_ session: AVContentKeySession, shouldProvidePersistableContentKeyForContentKeyIdentifier keyIdentifier: Any) -> Bool {
        return true // Allow persistable content keys
    }

    public func contentKeySession(_ session: AVContentKeySession, didUpdatePersistableContentKey persistableContentKey: Data, forContentKeyIdentifier keyIdentifier: Any) {
        // Save the persistable content key locally (e.g., in a secure location)
       
    }

    
    func fetchContentKey(for requestData: Data, completion: @escaping (Data?) -> Void) {
        // URL of your DRM license server
        guard let licenseServerURL = URL(string: "https://example.com/licenseServer") else {
            completion(nil)
            return
        }

        // Create a URL request with the request data
        var request = URLRequest(url: licenseServerURL)
        request.httpMethod = "POST"
        request.httpBody = requestData
        request.setValue("application/octet-stream", forHTTPHeaderField: "Content-Type")

        // Send the request
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error fetching content key: \(error.localizedDescription)")
                completion(nil)
                return
            }

            // Return the license data (CKC)
            completion(data)
        }
        task.resume()
    }

}
