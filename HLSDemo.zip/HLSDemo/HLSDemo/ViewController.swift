//
//  ViewController.swift
//  HLSDemo
//
//  Created by Gajje.Venkatarao on 12/12/24.
//

import UIKit
import AVKit
import AVFoundation

class ViewController: UIViewController {
    private var player: AVPlayer?
    private var playerLayer: AVPlayerLayer?
    private var contentKeySession: AVContentKeySession?
    
    private var proxy: ReverseProxyResourceLoader?
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let urlString = "localhost://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8"
        guard let url = URL(string: urlString) else {
            print("Invalid URL")
            return
        }
        
        //Create cookie to prepare for player asset
        
      let cookie =  HTTPCookie(properties: [
            .name: "dazn-token",
            .value: "cookie value",
            .domain: url.host() ?? "",
            .path: "/",
            .discard: true
        ])

        //Create cookie key to set AVURLAsset
        let options =  [AVURLAssetHTTPCookiesKey: [cookie]]
        
        let asset = AVURLAsset(url: url,options: options)
        proxy = ReverseProxyResourceLoader()
        proxy?.cookie = "exampleCookie"
     
        // Set resource loader delegate to moniter the chunks
        asset.resourceLoader.setDelegate(proxy, queue: DispatchQueue.global())
        // Load asset keys asynchronously (e.g., "playable")
        let keys = ["playable"]
        
        // Initialize the AVPlayer with the URL
        let playerItem = AVPlayerItem(asset: asset)
        self.player = AVPlayer(playerItem: playerItem)
        playerItem.addObserver(self, forKeyPath: "status", options: [.new, .initial], context: nil)

           // Observe 'error' property (if needed)
        playerItem.addObserver(self, forKeyPath: "error", options: [.new], context: nil)
        
        let contentKeySessionDelegate = ContentKeyDelegate()
        // Initialize AVContentKeySession
        let contentKeySession = AVContentKeySession(keySystem: .clearKey)
        self.contentKeySession = contentKeySession
        contentKeySession.setDelegate(contentKeySessionDelegate, queue: DispatchQueue.main)

        // Associate the asset with the content key session
        contentKeySession.addContentKeyRecipient(asset)

        
        // Create a layer for the AVPlayer and add it to the view
        playerLayer = AVPlayerLayer(player: player)
        playerLayer?.frame = view.bounds
        playerLayer?.videoGravity = .resizeAspect
        if let playerLayer = playerLayer {
            view.layer.addSublayer(playerLayer)
        }
        
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(playerDidFinishPlaying),
            name: .AVPlayerItemDidPlayToEndTime,
            object: player?.currentItem
        )
        
        // Start playback
        player?.play()
    }
    
    // Update cookie when ever needed
    func updateCookie() {
        proxy?.cookie = "update exampleCookie"
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        if let playerLayer = view.layer.sublayers?.compactMap({ $0 as? AVPlayerLayer }).first {
            playerLayer.frame = view.bounds
        }
    }
    
    @objc private func playerDidFinishPlaying(notification: Notification) {
        print("Playback finished!")
        // Optionally, handle end-of-playback actions here
    }
    
    deinit {
        // Remove observers to avoid memory leaks
        NotificationCenter.default.removeObserver(self)
    }
    
    
}

/// Observe Player status
extension ViewController {
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        guard let playerItem = object as? AVPlayerItem else { return }

        if keyPath == "status" {
            switch playerItem.status {
            case .readyToPlay:
                print("Player is ready to play")
            case .failed:
                print("Player failed with error: \(playerItem.error?.localizedDescription ?? "Unknown error")")
            case .unknown:
                print("Player status is unknown")
            @unknown default:
                print("Unhandled player status")
            }
        } else if keyPath == "error" {
            if let error = playerItem.error {
                print("Player error: \(error.localizedDescription)")
            }
        }
    }
}


